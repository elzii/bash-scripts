#if 0
	shc Version 3.8.9, Generic Script Compiler
	Copyright (c) 1994-2012 Francisco Rosales <frosal@fi.upm.es>

	./shc -v -f match 
#endif

static  char data [] = 
#define      chk1_z	22
#define      chk1	((&data[2]))
	"\273\356\031\374\053\211\002\045\033\027\276\125\274\100\117\036"
	"\262\113\011\362\325\141\324\040\167"
#define      msg2_z	19
#define      msg2	((&data[27]))
	"\306\122\167\273\372\147\003\017\202\214\240\031\251\357\051\010"
	"\122\102\160\111\145"
#define      shll_z	8
#define      shll	((&data[47]))
	"\232\237\277\167\063\162\216\236\006\040\214"
#define      xecc_z	15
#define      xecc	((&data[59]))
	"\116\224\172\016\057\137\122\170\006\163\336\060\235\327\377\332"
	"\163\373"
#define      pswd_z	256
#define      pswd	((&data[111]))
	"\140\165\365\031\077\355\314\241\356\216\270\236\274\257\032\367"
	"\021\213\272\143\002\062\042\222\046\265\234\331\004\210\130\237"
	"\055\265\027\224\072\371\007\100\246\030\236\035\345\154\275\334"
	"\276\147\061\250\340\170\160\104\240\134\133\107\111\152\203\026"
	"\133\356\265\020\261\165\350\321\342\171\127\130\373\350\302\205"
	"\251\327\366\341\231\376\021\213\166\201\115\271\001\232\004\253"
	"\104\047\127\050\343\325\255\225\071\042\245\346\217\234\110\224"
	"\106\077\217\170\102\325\257\213\010\270\206\217\270\333\136\331"
	"\316\230\273\255\345\353\017\231\163\121\115\076\106\276\054\131"
	"\030\006\114\112\040\162\230\275\112\051\107\124\231\103\160\253"
	"\335\175\163\262\057\367\122\012\330\115\034\102\315\350\252\237"
	"\050\255\207\252\363\333\207\246\100\323\150\320\055\254\141\163"
	"\231\325\177\146\022\372\212\271\316\374\342\373\061\271\342\016"
	"\061\120\242\107\103\233\140\323\347\011\123\055\121\236\003\215"
	"\166\200\363\013\133\366\314\165\317\226\100\012\350\162\016\027"
	"\312\245\163\343\146\006\133\066\376\342\344\237\132\201\122\101"
	"\306\367\340\347\137\340\165\173\333\344\340\110\231\167\134\226"
	"\226\341\041\116\007\361\160\334\336\227\031\316\330\273\154\071"
	"\014\102\316\144\006\053\143\034\372\131\150\322\031\065\310\124"
	"\017\331\335\133\354\032\310\305\123\323\041\116\121\101\226\374"
	"\366\047\223\103\231\304\312\014\160"
#define      msg1_z	42
#define      msg1	((&data[413]))
	"\175\117\214\055\365\216\302\034\176\220\210\051\102\356\271\105"
	"\066\164\357\254\351\010\350\243\300\037\131\277\272\213\215\270"
	"\360\277\211\031\011\154\314\340\034\071\065\075\206\175\157\024"
	"\154\245\330\067\101\305\304\131\233"
#define      date_z	1
#define      date	((&data[461]))
	"\342"
#define      tst2_z	19
#define      tst2	((&data[463]))
	"\132\113\101\214\152\364\127\371\216\013\004\222\347\252\203\115"
	"\271\326\352\216\312\123\257\040"
#define      text_z	337
#define      text	((&data[560]))
	"\022\300\331\173\124\032\141\074\260\340\311\231\321\171\265\141"
	"\366\162\174\030\241\213\313\020\067\042\327\373\031\371\065\347"
	"\233\154\226\232\256\045\066\174\154\207\124\352\017\226\001\364"
	"\213\176\347\206\072\004\376\370\135\204\105\127\275\200\140\156"
	"\033\023\044\077\055\372\112\175\234\326\340\304\243\102\113\052"
	"\070\336\073\222\216\321\203\161\316\265\374\315\154\060\107\270"
	"\153\074\316\065\377\265\314\152\014\211\145\312\246\131\311\377"
	"\371\227\263\041\031\023\252\037\021\126\023\212\263\113\320\304"
	"\033\245\003\374\115\100\115\051\370\372\174\374\036\307\206\200"
	"\012\122\261\010\363\040\201\151\047\324\151\053\360\346\260\123"
	"\000\276\056\300\151\366\326\340\230\350\204\036\171\210\123\034"
	"\373\041\045\156\174\322\166\252\327\053\201\041\156\210\125\375"
	"\155\173\232\372\356\172\057\013\271\313\367\275\001\136\357\155"
	"\072\124\047\012\200\302\131\203\340\020\240\232\203\012\351\124"
	"\303\124\223\227\257\243\175\065\257\007\253\052\056\060\224\013"
	"\343\042\342\372\342\271\331\276\125\302\065\306\353\033\164\230"
	"\100\371\036\024\124\004\310\245\265\241\117\135\261\010\233\143"
	"\010\243\070\144\147\131\054\135\133\261\224\023\163\116\322\126"
	"\056\145\221\050\241\025\103\261\066\125\340\221\154\260\103\203"
	"\207\100\163\274\070\075\166\174\121\341\145\046\020\376\057\157"
	"\047\021\046\005\251\024\055\304\160\005\153\352\356\013\333\356"
	"\130\310\142\170\315\074\057\335\377\375\207\166\121\257\034\121"
	"\163\141\041\231\256\121\173\006\133\226\101\203\253\224\361\077"
	"\000\221\101\155\152\344\053\333\250\235\331\032\253\003\174\330"
	"\031\066\344\107\100\224\145\321\120\302\064\077\125\151\275\054"
	"\076\071\222\056\054\341\031\042\277\010\223\264\303\367\157\111"
	"\107\164\313\204\104\172\361\004\260\310\325\361\064\372\343\126"
	"\361\342\111\307\114\124\125\075\107\336\322\020\133\245\044\111"
	"\074\262\150\360\231\224\102\314\077"
#define      rlax_z	1
#define      rlax	((&data[943]))
	"\224"
#define      chk2_z	19
#define      chk2	((&data[948]))
	"\346\176\371\354\116\315\011\251\144\004\246\120\020\152\001\202"
	"\032\330\165\163\324\102\070\050\162"
#define      inlo_z	3
#define      inlo	((&data[969]))
	"\222\240\276"
#define      opts_z	1
#define      opts	((&data[972]))
	"\372"
#define      lsto_z	1
#define      lsto	((&data[973]))
	"\227"
#define      tst1_z	22
#define      tst1	((&data[974]))
	"\221\030\246\104\046\151\076\164\014\347\027\104\135\242\144\334"
	"\150\367\337\335\170\177\205\256\222\121"/* End of data[] */;
#define      hide_z	4096
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	0	/* Define as 1 to enable ptrace the executable */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask  = (unsigned long)&chkenv;
	mask ^= (unsigned long)getpid() * ~mask;
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
#	define PTRACE_ATTACH	PT_ATTACH
#endif
void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PTRACE_ATTACH, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = getenv("_");
	if (me == NULL) { me = argv[0]; }

	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	ret = chkenv(argc);
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
	varg[j++] = argv[0];		/* My own name at execution */
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
